import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Page Title
st.set_page_config(page_title="Task 1 - EDA Dashboard", layout="wide")

st.title("📊 Task 1: Foundational Setup & Exploratory Data Analysis (EDA)")

# Load Dataset
try:
    df = pd.read_csv("dataset.csv")

    st.success("Dataset Loaded Successfully!")

    # Dataset Preview
    st.header("1. Dataset Preview")
    st.dataframe(df.head())

    # Dataset Information
    st.header("2. Dataset Information")
    st.write("Shape:", df.shape)
    st.write("Columns:", list(df.columns))

    # Statistics
    st.header("3. Statistical Summary")
    st.write(df.describe())

    # Missing Values
    st.header("4. Missing Values")
    st.write(df.isnull().sum())

    # Remove Duplicates
    df = df.drop_duplicates()

    # Histogram
    st.header("5. Histogram")
    fig, ax = plt.subplots()
    df["Sales"].hist(ax=ax)
    st.pyplot(fig)

    # Boxplot
    st.header("6. Boxplot")
    fig, ax = plt.subplots()
    ax.boxplot(df["Sales"])
    st.pyplot(fig)

    # Bar Chart
    st.header("7. Category Wise Sales")
    category_sales = df.groupby("Category")["Sales"].sum()

    fig, ax = plt.subplots()
    category_sales.plot(kind='bar', ax=ax)
    st.pyplot(fig)

    # Scatter Plot
    st.header("8. Scatter Plot")
    fig, ax = plt.subplots()
    ax.scatter(range(len(df)), df["Sales"])
    ax.set_xlabel("Index")
    ax.set_ylabel("Sales")
    st.pyplot(fig)

    # Correlation
    st.header("9. Correlation Heatmap")
    corr = df.select_dtypes(include='number').corr()

    fig, ax = plt.subplots()
    cax = ax.matshow(corr)
    plt.colorbar(cax)

    ax.set_xticks(range(len(corr.columns)))
    ax.set_yticks(range(len(corr.columns)))
    ax.set_xticklabels(corr.columns)
    ax.set_yticklabels(corr.columns)

    st.pyplot(fig)

    # Insights
    st.header("10. Findings")
    st.write("✅ Trends identified")
    st.write("✅ Patterns analyzed")
    st.write("✅ Anomalies checked")
    st.write("✅ Dataset cleaned")

except FileNotFoundError:
    st.error("Please keep dataset.csv in the same folder as app.py")